import socket
import time
import string
port = 12321
server = ''
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
address = (server, port)
sock.bind(address)
packets = []
binary_packets=[]

print("The socket is open")

d, _ = sock.recvfrom(100)
d = int.from_bytes(d, "big")
print("the random number is :", d)

while True:
    data, addr = sock.recvfrom(100)
    data=data.decode()
    packets.append(data)
    if data == 'END!':
        print("Received Successfully")
        break
    else:
        print(data)
        print(addr)

sock.close()
print("The socket is close")
print(packets)

packets.pop()
e=int(packets.pop())


# packets.remove('Joker')

for word in packets:
    res=''.join(format(ord(i),'08b')for i in word)
    binary_packets.append(res)




if d>len(packets)-2:
    for b_p in binary_packets:
        e = e ^ int(b_p)
    diff = 0
    while True:
        rev = ''.join(chr(int(''.join(x), 2)) for x in zip(*[iter(str(diff * '0') + str(e))] * 8))
        if rev.isascii():
            break
        else:
            diff = diff + 1
    print('The missing Packet is: ' , rev)
