import socket
import time
import random
from operator import xor

server = '10.0.0.16'
port = 12321
address = (server, port)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
num=1
msg_list = ["Can", "You", "Introduce", "Me", "As", "Joker", "?"]
msg_binary=[]

e=0
print(e)
for word in msg_list:
    res=''.join(format(ord(i),'08b')for i in word)
    msg_binary.append(res)
print(msg_binary)

for word in msg_binary:
    e=e^int(word)
print(e)

# print("************************")

# for word in msg_binary:
#     e=e^int(word)
# print(e)


#sending the random number d.
d=random.randint(7,7)
print("the random number is :",d)
sock.sendto(d.to_bytes(2,byteorder='big'), address)

# sending the messages
for word in msg_list:
    time.sleep(3)
    sock.sendto(word.encode('utf-8'), address)
    print(num,"massege sent")
    num+=1
sock.sendto(str(e).encode("utf-8"),address)
sock.sendto(b'END!', address)



