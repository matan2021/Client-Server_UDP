from scapy.all import *
import time
import os
import sys

def packet_callback(pkg):
	print(pkg.show())
	file1 = open('check.txt', 'w')
	if str(pkg[Raw].load)== "b\'You\'":
		
		os.system('echo 0 > /proc/sys/net/ipv4/ip_forward')	
	else:
		os.system('echo 1 > /proc/sys/net/ipv4/ip_forward')	


def main():
	sniff(prn=packet_callback,filter='udp and host 10.0.0.16 and port 12321',store=False)

		
		


if __name__=='__main__':
    main()















